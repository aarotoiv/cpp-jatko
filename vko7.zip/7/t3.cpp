#include "Murtoluku.h"

int main() {
    Murtoluku luku(5, 10);
    luku.tulosta();

    return 0;
}